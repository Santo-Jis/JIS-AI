/**
 * WhatsApp Web Automation - Baileys Bridge
 * QR কোড স্ক্যান করে WhatsApp সংযোগ করো
 * মেসেজ Python Backend এ পাঠায়
 */

const { default: makeWASocket, DisconnectReason, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const axios = require('axios');
const pino = require('pino');

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000';

async function startWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');

    const sock = makeWASocket({
        logger: pino({ level: 'silent' }),
        auth: state,
        printQRInTerminal: true, // টার্মিনালে QR কোড দেখাবে
    });

    // Auth সেভ করো
    sock.ev.on('creds.update', saveCreds);

    // Connection handle
    sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
        if (qr) {
            console.log('\n📱 QR কোড স্ক্যান করুন আপনার WhatsApp দিয়ে!\n');
        }
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('❌ সংযোগ বিচ্ছিন্ন। পুনরায় সংযোগ:', shouldReconnect);
            if (shouldReconnect) {
                setTimeout(startWhatsApp, 3000);
            }
        } else if (connection === 'open') {
            console.log('✅ WhatsApp সংযুক্ত হয়েছে!');
        }
    });

    // মেসেজ আসলে handle করো
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const msg of messages) {
            // নিজের মেসেজ বাদ দাও
            if (msg.key.fromMe) continue;

            const phone = msg.key.remoteJid.replace('@s.whatsapp.net', '').replace('@g.us', '');
            const text = msg.message?.conversation ||
                         msg.message?.extendedTextMessage?.text || '';

            if (!text) continue;

            console.log(`📩 ${phone}: ${text}`);

            try {
                // Python Backend এ পাঠাও
                const response = await axios.post(`${BACKEND_URL}/webhook/baileys`, {
                    from: phone,
                    message: text,
                    timestamp: new Date().toISOString()
                });

                // AI রিপ্লাই পাঠাও
                if (response.data?.reply) {
                    await sock.sendMessage(
                        msg.key.remoteJid,
                        { text: response.data.reply }
                    );
                    console.log(`✅ রিপ্লাই পাঠানো হয়েছে: ${response.data.reply.substring(0, 50)}...`);
                }
            } catch (err) {
                console.error('❌ Backend Error:', err.message);
                // Fallback মেসেজ
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: 'দুঃখিত, এই মুহূর্তে সমস্যা হচ্ছে। একটু পরে আবার চেষ্টা করুন। 🙏' }
                );
            }
        }
    });

    return sock;
}

// শুরু করো
console.log('🚀 WhatsApp Bot শুরু হচ্ছে...');
startWhatsApp().catch(console.error);
