# 🚀 AI Customer Care - সম্পূর্ণ সেটআপ গাইড

## ফাইল স্ট্রাকচার
```
ai-customer-care/
├── app/
│   ├── main.py               ← FastAPI Server (মূল সার্ভার)
│   ├── ai_engine.py          ← AI Brain (Claude API)
│   ├── knowledge_base.py     ← FAQ ও জ্ঞান ভান্ডার
│   ├── conversation_manager.py ← কথোপকথন ব্যবস্থাপনা
│   ├── database.py           ← ডেটা সংরক্ষণ
│   └── config.py             ← সেটিংস
├── whatsapp_bot/
│   └── index.js              ← WhatsApp Automation (Baileys)
├── requirements.txt
├── .env.example
└── SETUP.md
```

---

## ধাপ ১: VPS এ Python সেটআপ

```bash
# VPS এ SSH করুন
ssh root@your-vps-ip

# Python ও pip আপডেট করুন
sudo apt update && sudo apt upgrade -y
sudo apt install python3 python3-pip python3-venv -y

# প্রজেক্ট ফোল্ডারে যান
cd ai-customer-care

# Virtual environment তৈরি করুন
python3 -m venv venv
source venv/bin/activate

# Dependencies ইনস্টল করুন
pip install -r requirements.txt
```

---

## ধাপ ২: .env ফাইল তৈরি করুন

```bash
cp .env.example .env
nano .env
```

নিচের তথ্য দিন:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx   ← anthropic.com থেকে নিন
WHATSAPP_VERIFY_TOKEN=যেকোনো_গোপন_শব্দ
SECRET_KEY=যেকোনো_র্যান্ডম_স্ট্রিং
```

---

## ধাপ ৩: Backend চালু করুন

```bash
cd app
python3 -c "
import asyncio
from database import Database
asyncio.run(Database().initialize())
print('✅ Database তৈরি হয়েছে!')
"

# Server চালু করুন
uvicorn main:app --host 0.0.0.0 --port 8000
```

এখন খুলুন: `http://your-vps-ip:8000/health`
✅ দেখাবে: `{"status": "running ✅"}`

---

## ধাপ ৪: WhatsApp Baileys সেটআপ

```bash
# Node.js ইনস্টল করুন
sudo apt install nodejs npm -y

# WhatsApp bot ফোল্ডারে যান
cd whatsapp_bot
npm init -y
npm install @whiskeysockets/baileys axios pino

# চালু করুন
BACKEND_URL=http://localhost:8000 node index.js
```

**টার্মিনালে QR কোড আসবে → WhatsApp দিয়ে স্ক্যান করুন**
✅ দেখাবে: "WhatsApp সংযুক্ত হয়েছে!"

---

## ধাপ ৫: 24/7 চালু রাখুন (PM2)

```bash
# PM2 ইনস্টল করুন
npm install -g pm2

# Backend চালু করুন
pm2 start "uvicorn main:app --host 0.0.0.0 --port 8000" --name "ai-backend"

# WhatsApp Bot চালু করুন
pm2 start whatsapp_bot/index.js --name "whatsapp-bot"

# অটো স্টার্ট সেট করুন
pm2 startup
pm2 save
```

---

## API Test করুন

```bash
# Chat test
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "test_001",
    "message": "আপনাদের পণ্যের দাম কত?",
    "platform": "web"
  }'

# Stats দেখুন
curl http://localhost:8000/api/stats

# নতুন FAQ যোগ করুন
curl -X POST http://localhost:8000/api/train \
  -H "Content-Type: application/json" \
  -d '{
    "question": "ডিসকাউন্ট পাবো?",
    "answer": "হ্যাঁ! ১০০০ টাকার বেশি অর্ডারে ১০% ছাড় পাবেন।",
    "category": "product_info"
  }'
```

---

## সব API Endpoints

| Method | URL | কাজ |
|--------|-----|-----|
| POST | `/api/chat` | AI চ্যাট |
| POST | `/api/manual-reply` | Agent রিপ্লাই |
| POST | `/api/toggle-ai` | AI চালু/বন্ধ |
| POST | `/api/train` | নতুন FAQ শেখাও |
| GET | `/api/stats` | Dashboard stats |
| GET | `/api/conversations` | সব কথোপকথন |
| GET | `/api/order/{id}` | অর্ডার দেখো |
| WS | `/ws/dashboard` | Live updates |
| POST | `/webhook/whatsapp` | Meta Webhook |
| POST | `/webhook/baileys` | Baileys Webhook |

---

## পরবর্তী ধাপ (ধাপ ২)
- ✅ Web Dashboard (React)
- ✅ Mobile App (React Native)
- ✅ WhatsApp Business API সংযোগ

**সাহায্য লাগলে জানান! 🚀**
